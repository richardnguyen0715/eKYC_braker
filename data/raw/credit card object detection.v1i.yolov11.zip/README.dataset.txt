# credit card object detection > 2024-04-07 12:44pm
https://universe.roboflow.com/karthik-b1wgt/credit-card-object-detection

Provided by a Roboflow user
License: CC BY 4.0

